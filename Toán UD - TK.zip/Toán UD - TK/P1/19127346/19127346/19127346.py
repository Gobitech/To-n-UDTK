import numpy as np

def copyMatrix(A):
    A_res = []
    for i in range(len(A)):
        A_row = []
        for j in range(len(A[i])):
            A_row.append(A[i][j])
        A_res.append(A_row)

    return A_res

def checkAllZero(row):
    for i in row:
        if i != 0:
            return False
    return True

def removeAllZeroRow(A):
    for row in A:
        if checkAllZero(row):
            A.remove(row)

def removeSameRatio(A):
    for i in range(len(A) - 1):
        for j in range(len(A[i])):
            if i == len(A) - 1:
                break
            if (A[i][j] != 0) & (A[i + 1][j] != 0):
                if j == len(A[i]) - 1:
                    if checkAllZero(A[i][:j]) & checkAllZero(A[i + 1][:j]):
                        A.remove(A[i + 1])
                        break
                    break
                temp = A[i][j] / A[i + 1][j]
                count = 0;
                for k in range(j + 1, len(A[i])):
                    if A[i][j] / A[i + 1][j] != temp:
                        count = 1
                        break
                if count == 0:
                    A.remove(A[i + 1])
                    break



def level(A):
    lev = []
    for row in range(len(A)):
        for col in range(len(A[row])):
            if A[row][col]:
                if col not in lev:
                    lev.append(col)
                break
    return lev

def checkFreedom(A, col):
    if col not in level(A):
        return True
    return False

def levelOfRow(row):
    for col in range(len(row)):
        if row[col]:
            return col

def checkExistFreedomDifZero(A, row):
    for col in range(len(row)):
        if (row[col] != 0) & (checkFreedom(A, col)):
            return True
    return False

def checkIsNumber(num):
    try:
        float(num)
        return True
    except:
        return False

def reduceCal(string):
    if (type(string) == float):
        return string

    temp = string.split()
    num = 0
    pos = []
    count = 0
    for value in temp:
        if checkIsNumber(value):
            value = float(value)
            num += value
            pos.append(count)
        else:
            find_1 = value.find('(')
            find_2 = value.find(')')
            if (find_1 != -1) & (find_2 != -1) & (value.count('(') == 1) & (value.count(')') == 1):
                if checkIsNumber(value[find_1 + 1 : find_2]):
                    count_ = value.count('-')
                    if not count_ % 2:
                        value = -float(value[find_1 + 1 : find_2])
                    else:
                        value = float(value[find_1 + 1 : find_2])

                    num += value
                    pos.append(count)
        count += 1

    if num:
        result = str(num)
    else:
        result = ''

    for i in range(len(temp)):
        if (type(temp[i]) == str):
            if i not in pos:
                result += ' ' + temp[i]

    return result

def calInfiRow(A, row):
    n = len(row)

    if not row[n - 1]:
        return 0

    result = f'{row[n - 1]}'
    for col in range(len(row) - 1):
        if row[col]:
            if checkFreedom(A, col):
                if checkIsNumber(row[col]):
                    row[col] = f'{row[col]}x' + str(col + 1)
                else:
                    row[col] = f'({row[col]})x' + str(col + 1)

            if type(row[col]) == float:
                if checkIsNumber(result):
                    result = float(result) - row[col]
                else:
                    if row[col] < 0:
                        result = str(result) + f' -({row[col]})'
                    else:
                        result = str(result) + f' -{row[col]}'
            else:
                result = str(result) + f' -{row[col]}'

    return reduceCal(result)

def infinity(A):
    removeAllZeroRow(A)
    removeSameRatio(A)
    m = len(A)
    x = []
    for i in range(m - 1, -1, -1):
        if not checkExistFreedomDifZero(A, A[i]):
            if (type(A[i][m]) == float) & ((type(A[i][levelOfRow(A[i])])) == float):
                x.insert(0, A[i][m] / A[i][levelOfRow(A[i])])
            else:
                x.insert(0, f'({A[i][m]})/({A[i][levelOfRow(A[i])]})')
        else:
            x.insert(0, calInfiRow(A, A[i]))

        for k in range(i - 1, -1, -1):
            if (checkIsNumber(A[k][i])) & (checkIsNumber(x[0])):
                A[k][m] -= float(A[k][i]) * float(x[0])
            else:
                A[k][m] = f' -({A[k][i]})({x[0]})'

    return x

def Gauss_elimination(A):
    A_res = copyMatrix(A)

    m = len(A_res)
    assert all([len(row) == m + 1 for row in A_res[:]]), "Matrix rows have non-uniform length"
    n = m + 1
    
    for k in range(m):
        pivots = [abs(A_res[i][k]) for i in range(k, m)]
        i_max = pivots.index(max(pivots)) + k
        
        # Check for singular matrix
        #assert A_res[i_max][k] != 0, "Matrix is singular!"
        
        # Swap rows
        A_res[k], A_res[i_max] = A_res[i_max], A_res[k]

        
        for i in range(k + 1, m):
            if A_res[k][k] != 0:
                f = A_res[i][k] / A_res[k][k]
                for j in range(k + 1, n):
                    A_res[i][j] -= A_res[k][j] * f

            # Fill lower triangular matrix with zeros:
            A_res[i][k] = 0
    return A_res

def back_substitution(A):
    # Solve equation Ax=b for an upper triangular matrix A         
    x = []
    m = len(A)
    for i in range(m - 1, -1, -1):
        if A[i][i] != 0:
            x.insert(0, A[i][m] / A[i][i])
            for k in range(i - 1, -1, -1):
                A[k][m] -= A[k][i] * x[0]
        else:
            if A[i][m] != 0:
                return 'vo nghiem'
            else:
                return 'vo so nghiem'
    return x

def inputMatrix():
    n = int(input('Enter number of unknowns: '))

    a = np.zeros((n,n+1))
    print('Enter Augmented Matrix Coefficients:')
    for i in range(n):
        for j in range(n+1):
            a[i][j] = float(input(f'a[{i}][{j}]='))

    return a

if __name__ == '__main__':
    A = [[1,2,4,5],
         [1,2,3,4],
         [5,6,7,8]]
    #res = Gauss_elimination(A)
    #print(res)
    #removeAllZeroRow(res)
    #print(res)
    #print(A)
    #print(back_substitution(res))
    #print(chr(97))
    
    print(back_substitution(Gauss_elimination(A)))
