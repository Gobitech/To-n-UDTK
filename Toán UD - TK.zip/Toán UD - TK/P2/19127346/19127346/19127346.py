import copy


print("Matrix A(N x N): ")
n = int(input("Input N: "))
m = int(input("Input M: "))
A = []


def InputMatrix():
    if n <= 1:
        print("Matrix does not match\n")
    else:
        print("Input the element of Matrix A:")
        for i in range(n):
            b = []
            for j in range(m):
                b.append(float(input("a[" + str(i) + "][" + str(j) + "]: ")))
            A.append(b)
        return A

def print_matrix(string, A):
    print(string)
    for row in A:
        for col in row:
            print(col, end = '   ')
        print()

def print_A_I_matrix(A):
    for row in range(len(A)):
        for col in range(len(A[row])):
            if col == int(len(A[row])/2):
                print("\t|\t", end='')
            print(A[row][col], end='   ')
        print()

def idMatx(size):
    id = []
    for i in range(size):
        id.append([0]*size)
    for i in range(size):
        id[i][i] = 1
    return id
 
def tranMtx(inMtx):
    tMtx = []
    for row in range(len(inMtx[0])):
        tRow = []
        for col in range(len(inMtx)):
            ele = inMtx[col][row]
            tRow.append(ele)
        tMtx.append(tRow)
    return tMtx
 
def matxRound(matx, decPts=4):
    for col in range(len(matx)):
        for row in range(len(matx[0])):
            matx[col][row] = round(matx[col][row], decPts)

def to_float(matx):
    for col in range(len(matx)):
        for row in range(len(matx[0])):
            matx[col][row] = float(matx[col][row])
 
# the solver ...

def create_submatrix(A, i_row, i_col):
    sub_A = copy.deepcopy(A)

    sub_A = sub_A[:i_row] + sub_A[i_row+1:]

    n_row_sub = len(sub_A)
    for i in range(n_row_sub):
        sub_A[i] = sub_A[i][:i_col] + sub_A[i][i_col+1:]

    return sub_A

def determinant(A):
    if len(A) == 1 and len(A[0]) == 1:
        return A[0][0]

    total = 0
    for i_col in range(len(A[0])):
        sub_A = create_submatrix(A, 0, i_col)
        sign = (-1) ** (i_col % 2)
        sub_det = determinant(sub_A)
        total += sign * A[0][i_col] * sub_det

    return total

def permutation(matx):
    colrange = len(matx)
    for col in range(colrange):
        bigrow = col
        for row in range(col+1, colrange):
            if abs(matx[row][col]) > abs(matx[bigrow][col]):
                bigrow = row
                matx[col], matx[bigrow] = matx[bigrow], matx[col]

def getResultFrom_A_I_matrix(matx):
    augCol = len(matx[0])
    matrix_result = []
    for col in range(int(augCol/2), augCol):
        col_A = []
        for row in range(len(matx)):
            col_A.append(matx[row][col])
        matrix_result.append(col_A)
    return matrix_result
 
def reverse(A, decPts=4):
    assert all([len(row) == len(A) for row in A[:]]), 'Matrix rows have non-uniform length'

    assert determinant(A) != 0, 'Matrix irreversible'

    ii = idMatx(len(A))
    Aa = A[:]
    for col in range(len(ii)):
        Aa.append(ii[col])
    tAa = tranMtx(Aa)
    m = tAa[:]
 
    (eqns, colrange, augCol) = (len(A), len(A), len(m[0]))
 
    # permute the matrix -- get the largest leaders onto the diagonals
    # take the first row, assume that x[1,1] is largest, and swap if that's not true
    permutation(m)
 
    # reduce, such that the last row is has at most one unknown
    for rrcol in range(0, colrange):
        for rr in range(rrcol+1, eqns):
            cc = -(float(m[rr][rrcol])/float(m[rrcol][rrcol]))
            for j in range(augCol):
                m[rr][j] = m[rr][j] + cc*m[rrcol][j]
 
    # final reduction -- the first test catches under-determined systems
    # these are characterised by some equations being all zero
    for rb in reversed(range(eqns)):
        if ( m[rb][rb] == 0):
            if m[rb][augCol-1] == 0:
                continue
            else:
                print('system is inconsistent')
                return
        else:
            # you must loop back across to catch under-determined systems
            for backCol in reversed(range(rb, augCol)):
                m[rb][backCol] = float(m[rb][backCol]) / float(m[rb][rb])
            # knock-up (cancel the above to eliminate the knowns)
            # again, we must loop to catch under-determined systems
            if not (rb == 0):
                for kup in reversed(range(rb)):
                    for kleft in reversed(range(rb, augCol)):
                        kk = -float(m[kup][rb]) / float(m[rb][rb])
                        m[kup][kleft] += kk*float(m[rb][kleft])
 
    matxRound(m, decPts)
    print('Matrix (A|I) is')
    print_A_I_matrix(m)
 
    return getResultFrom_A_I_matrix(m)

# A = [[1,3,2,1],
#      [0,1,-1,-1],
#      [0,0,1,3],
#      [0,0,0,1]]
 
InputMatrix()

print_matrix("Matrix is",A)

print_matrix("Reverse matrix is",reverse(A,1))