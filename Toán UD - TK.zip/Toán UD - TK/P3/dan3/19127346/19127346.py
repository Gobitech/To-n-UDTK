import pandas as pd 
import matplotlib.pyplot as plt
import numpy as np
import sympy
from sympy import Matrix


def find_theta(A, b):
    return np.linalg.inv(A.T @ A) @ (A.T @ b)

def find_standardized_residual(A, b, x_hat):
    return np.linalg.norm(A @ x_hat - b)

def A(attributes, qualities):
    x_hat = find_theta(attributes, qualities)

    string = 'y = '
    string += f'{round(x_hat[0][0], 3)}X1'
    for i in range(1, 11):
        if x_hat[i][0] >= 0:
            string += f' + {round(x_hat[i][0], 3)}X{i+1}'
        else:
            string += f' - {abs(round(x_hat[i][0], 3))}X{i+1}'

    return string, round(find_standardized_residual(attributes, qualities, x_hat), 3)

def B(attributes, qualities):
    attributes_list = []
    transpose = attributes.T

    count = 1
    for value in transpose:
        value = value.reshape(len(value), 1)

        x_hat = find_theta(value, qualities)
        string = f"y = {round(x_hat[0][0], 3)}X{count}"

        attributes_list.append([string, np.round(find_standardized_residual(value, qualities, x_hat), 3)])

        count += 1

    return attributes_list

def C(attributes, qualities):
    transpose = attributes.T

    index = 0
    sqrt_index = []
    for i in transpose:
        flag = 0
        for j in i:
            if 0 < abs(j) < 1:
                flag = 1
                transpose[index] = np.sqrt(i)
                sqrt_index.append(index)
                index += 1
                break

        if flag == 1:
            continue

        transpose[index] = np.log10(i)

    just_one_array = [[1] * len(transpose[0])]
    transpose = np.concatenate((just_one_array, transpose))
    transpose = transpose.T

    x_hat = find_theta(transpose, qualities)

    string = f'y = {round(x_hat[0][0], 3)}'
    for i in range(1, 12):
        if (i + 1) in sqrt_index:
            if x_hat[i][0] >= 0:
                string += f' + {round(x_hat[i][0], 3)}sqrt(X{i})'
            else:
                string += f' - {abs(round(x_hat[i][0], 3))}sqrt(X{i})'
        else:
            if x_hat[i][0] >= 0:
                string += f' + {round(x_hat[i][0], 3)}log(X{i})'
            else:
                string += f' - {abs(round(x_hat[i][0], 3))}log(X{i})'

    return string, round(find_standardized_residual(transpose, qualities, x_hat), 3)

if __name__ == '__main__':
    df = pd.read_csv('wine.csv', sep=';')

    input_cols = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar',
       'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density',
       'pH', 'sulphates', 'alcohol']
    output_cols = ['quality']

    attributes = df[input_cols].values
    qualities = df[output_cols].values

    print('=====A=====\n')

    a = A(attributes, qualities)
    print('Mô hình đánh giá:')
    print(a[0])
    print(f'Chuẩn vector phần dư: {a[1]}\n')

    print('=====B=====\n')

    b = B(attributes, qualities)

    index = 0
    min_ = b[index][1]
    string = ''
    for mem in input_cols:
        print(f'Mô hình đánh giá {input_cols[index]}: \n\t\t{b[index][0]}')

        if min_ > b[index][1]:
            string = mem
            min_ = b[index][1]

        index += 1

    print(f"Đặc trưng cho kết quả tốt nhất là {string.upper()}\n")

    print('=====C=====\n')

    c = C(attributes, qualities)
    print('Mô hình đánh giá:')
    print(c[0])
    print(f'Chuẩn vector phần dư: {c[1]}\n')